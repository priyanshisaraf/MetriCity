import fetch from "node-fetch";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, ScanCommand } from "@aws-sdk/lib-dynamodb";
import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";
import { getThreshold } from "./thresholds.js"; // ✅ imported from your thresholds module

const docClient = DynamoDBDocumentClient.from(new DynamoDBClient({}));
const sesClient = new SESClient({ region: "ap-south-1"});

const OPENWEATHER_API_KEY = process.env.OPENWEATHER_API_KEY;
const AQICN_API_KEY = process.env.AQICN_API_KEY;

export const handler = async () => {
  try {
    const users = await getAllUsers();

    for (const user of users) {
      const weather = await fetchWeather(user.city);
      const aqiData = await fetchAQI(user.city);

      if (!weather || !aqiData) continue;

      const thresholds = user.mode === "manual"
        ? user.thresholds
        : getThreshold(user.city, user.ageGroup); 

      const shouldAlert = (
        aqiData.aqi > thresholds.aqi ||
        weather.temperature > thresholds.temp_max ||
        weather.humidity > thresholds.humidity_max
      );

      if (shouldAlert) {
        await sendAlertEmail(user.email, user.city, weather, aqiData, thresholds);
        console.log(`📧 Alert sent to ${user.email}`);
      } else {
        console.log(`✅ No alert needed for ${user.email}`);
      }
    }

    return { statusCode: 200, body: "Notifications processed." };
  } catch (err) {
    console.error("❌ Error:", err);
    return { statusCode: 500, body: "Error occurred" };
  }
};

const getAllUsers = async () => {
  const command = new ScanCommand({ TableName: "CityPulseUsers" });
  const result = await docClient.send(command);
  return result.Items || [];
};

const fetchWeather = async (city) => {
  try {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${OPENWEATHER_API_KEY}&units=metric`;
    const res = await fetch(url);
    const data = await res.json();
    return {
      temperature: data.main.temp,
      humidity: data.main.humidity
    };
  } catch (err) {
    console.error("Weather fetch error:", err);
    return null;
  }
};

const fetchAQI = async (city) => {
  try {
    const url = `https://api.waqi.info/feed/${city}/?token=${AQICN_API_KEY}`;
    const res = await fetch(url);
    const data = await res.json();
    return {
      aqi: data.data.aqi
    };
  } catch (err) {
    console.error("AQI fetch error:", err);
    return null;
  }
};

const sendAlertEmail = async (to, city, weather, aqi, thresholds) => {
  const subject = `⚠️ CityPulse Alert for ${city}`;
  const body = `
    Conditions in ${city} have exceeded your thresholds:

    - AQI: ${aqi.aqi} (Limit: ${thresholds.aqi})
    - Temperature: ${weather.temperature}°C (Limit: ${thresholds.temp_max}°C)
    - Humidity: ${weather.humidity}% (Limit: ${thresholds.humidity_max}%)

    Please take necessary precautions.

    — CityPulse
  `;

  const command = new SendEmailCommand({
    Destination: { ToAddresses: [to] },
    Message: {
      Subject: { Data: subject },
      Body: { Text: { Data: body } }
    },
    Source: "metricity.notify@gmail.com"
  });

  await sesClient.send(command);
};
