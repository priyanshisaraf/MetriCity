const AWS = require("aws-sdk");
const docClient = new AWS.DynamoDB.DocumentClient();

const thresholds = {
  global_defaults: {
    child: { aqi: 100, temp_max: 35, humidity_max: 70 },
    adult: { aqi: 120, temp_max: 40, humidity_max: 70 },
    elderly: { aqi: 100, temp_max: 35, humidity_max: 65 },
  },
  city_overrides: {
    delhi: {
      child: { aqi: 100, temp_max: 38.95, humidity_max: 65 },
      adult: { aqi: 120, temp_max: 42.22, humidity_max: 70 },
      elderly: { aqi: 100, temp_max: 38.95, humidity_max: 60 },
    },
    // Add other cities...
  },
};

exports.handler = async (event) => {
  const body = JSON.parse(event.body);
  const { email, city, ageGroup, mode, aqi, temp, humidity } = body;

  let finalThresholds = {};

  if (mode === "auto") {
    finalThresholds =
      thresholds.city_overrides[city]?.[ageGroup] ||
      thresholds.global_defaults[ageGroup];
  } else {
    finalThresholds = {
      aqi: parseFloat(aqi),
      temp_max: parseFloat(temp),
      humidity_max: parseFloat(humidity),
    };
  }

  const userItem = {
    email,
    city,
    ageGroup,
    mode,
    thresholds: finalThresholds,
  };

  const params = {
    TableName: "CityPulseUsers",
    Item: userItem,
  };

  await docClient.put(params).promise();

  return {
    statusCode: 200,
    body: JSON.stringify({ message: "User registered", data: userItem }),
  };
};
